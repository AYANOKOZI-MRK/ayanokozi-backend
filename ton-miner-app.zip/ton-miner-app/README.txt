TON Miner Telegram Mini App - Use Guide

1) ZIP unzip করো।
2) MongoDB Atlas থেকে connection string নাও।
3) Render এ New Web Service create করো।
4) এই project upload/connect করো।
5) Render Environment Variable এ add করো:
   MONGO_URI = তোমার MongoDB connection string
6) Render deploy হলে backend link কপি করো।
7) app.js খুলে API_URL এর জায়গায় তোমার Render link বসাও।
8) BOT_USERNAME এর জায়গায় তোমার bot username বসাও।
9) Frontend files: index.html, style.css, app.js Netlify তে deploy করো।
10) BotFather > /mybots > Bot Settings > Menu Button / Mini App URL এ Netlify link বসাও।

Note: এটা TON mining simulation app. Real TON payout auto করতে হলে payment/wallet API লাগবে।
